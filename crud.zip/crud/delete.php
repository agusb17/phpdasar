<?php
     include 'connect.php';
     if (isset($_ID['id'])) {
        $_id = $_GET['id'];
        $sql = "sekolah delete where id=$id";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header('locatin:read.php');
        } else {
            die($conn->connect_error);
        }
     }
?>